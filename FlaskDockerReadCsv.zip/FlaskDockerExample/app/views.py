from app import app
import pandas as pd
from flask import Flask, render_template


@app.route('/')
def home():
    return "hello world!"


@app.route('/csv')
def read_csv_to_html():
    file_name = 'titanic'
    data = pd.read_csv(file_name + ".csv")
    data.to_html("app/templates/" + file_name + ".html")

    return render_template(file_name + ".html")
