from app import app

# resources:
# https://hub.docker.com/r/tiangolo/uwsgi-nginx-flask
# https://www.fullstackpython.com/flask.html
# https://www.digitalocean.com/community/tutorials/how-to-build-and-deploy-a-flask-application-using-docker-on-ubuntu-18-04